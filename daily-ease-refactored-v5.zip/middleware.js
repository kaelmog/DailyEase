import { NextResponse } from "next/server";
import { verifyJwt } from "@/lib/auth";

export const config = {
  matcher: [
    "/reports/:path*",      // protect reports
    "/dashboard/:path*",    // protect dashboard
    "/api/reports/:path*",  // protect report APIs
    "/api/admin/:path*",    // protect admin APIs
  ],
};

export default function middleware(req) {
  const token = req.cookies.get("token")?.value;

  if (!token) {
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    return NextResponse.redirect(url);
  }

  try {
    verifyJwt(token);
    return NextResponse.next();
  } catch {
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    return NextResponse.redirect(url);
  }
}
