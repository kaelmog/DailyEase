// Vitest setup file
// Add any global test setup here (DOM matchers, global mocks, etc.)
/* Example:
import '@testing-library/jest-dom'
*/