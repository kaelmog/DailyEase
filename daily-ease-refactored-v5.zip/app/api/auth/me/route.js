import { NextResponse } from "next/server";
import { verifyJwt } from "@/lib/auth";

export async function GET(req) {
  const cookie = req.cookies.get("token");

  if (!cookie)
    return NextResponse.json({ user: null });

  try {
    const payload = verifyJwt(cookie.value);
    return NextResponse.json({ user: payload });
  } catch {
    return NextResponse.json({ user: null });
  }
}
