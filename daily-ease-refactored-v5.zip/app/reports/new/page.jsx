"use client";

import ReportForm from "@/components/ReportForm";

export default function NewReportPage() {
  return <ReportForm />;
}
