/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    proxyTimeout: 2000,
  },
};

export default nextConfig;
