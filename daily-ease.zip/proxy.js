// proxy.js
import { NextResponse } from "next/server";
import { verifyToken } from "@/lib/jwt";

export const config = {
  matcher: ["/((?!_next|api/auth|login|register|favicon.ico).*)"], // protect everything except login/register/api
};

export default async function proxy(req) {
  const { pathname } = req.nextUrl;

  // Allow login/register/api routes through
  if (
    pathname.startsWith("/api/auth") ||
    pathname.startsWith("/login") ||
    pathname.startsWith("/register")
  ) {
    return NextResponse.next();
  }

  // Get token from cookies
  const token = req.cookies.get("token")?.value;

  // Redirect to login if no token
  if (!token) {
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    return NextResponse.redirect(url);
  }

  try {
    verifyToken(token, process.env.JWT_SECRET);
    return NextResponse.next(); // valid token → allow
  } catch (err) {
    console.warn("Invalid token:", err.message);
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    return NextResponse.redirect(url);
  }
}
