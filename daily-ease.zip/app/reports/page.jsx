// File: app/reports/page.jsx
"use client";

import { useEffect, useState } from "react";
import ReportActions from "@/components/ReportActions";
import { fetcher } from "@/lib/utils";

export default function ReportsPage() {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const token =
    typeof window !== "undefined" ? localStorage.getItem("token") : null;

  console.log("CL REP ==>", reports);

  useEffect(() => {
    let mounted = true;
    async function load() {
      setLoading(true);
      setErr("");

      try {
        if (!token) throw new Error("Missing token");
        const data = await fetcher("/api/reports/list", {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        });
        if (mounted) setReports(Array.isArray(data) ? data : []);
      } catch (e) {
        console.error("Load reports error:", e);
        if (mounted) {
          setErr(e.message || "Error loading reports");
          setReports([]);
        }
      } finally {
        if (mounted) setLoading(false);
      }
    }

    load();
    return () => {
      mounted = false;
    };
  }, [token]);

  const handleDeleted = (id) => {
    setReports((prev) => prev.filter((r) => r.id !== id));
  };

  return (
    <div className="min-h-screen px-4 py-6 max-w-3xl mx-auto">
      <header className="mb-4">
        <h1 className="text-2xl font-bold">My Reports</h1>
      </header>

      {loading ? (
        <div>Loading reports...</div>
      ) : err ? (
        <div className="text-red-500">Error loading reports: {err}</div>
      ) : reports.length > 0 ? (
        <ul className="space-y-3">
          {reports.map((r) => (
            <li
              key={r.id}
              className="border rounded p-3 flex justify-between items-start"
            >
              <div className="flex-1">
                <div className="text-sm text-gray-400">{r.report_date}</div>
                <div className="text-lg font-medium">
                  Rp {r.total_sales ?? 0}
                </div>
                {r.notes && <div className="text-sm mt-1">{r.notes}</div>}
              </div>
              <div className="ml-4 flex-shrink-0">
                <ReportActions reportId={r.id} onDeleted={handleDeleted} />
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <div>No reports yet.</div>
      )}
    </div>
  );
}
